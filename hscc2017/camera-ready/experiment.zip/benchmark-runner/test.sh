#!/bin/bash
controller_a_size=3
controller_b_size=3
log_file=/users/pkesseli/documents/control-synthesis-benchmarks/benchmarks/CruiseControl/CruiseControl02_bound_simple.log
solution_a_items=`grep '<item>' ${log_file} | tail -n $((${controller_a_size}+${controller_b_size})) | head -n ${controller_a_size}`
solution_b_items=`grep '<item>' ${log_file} | tail -n ${controller_b_size}`
solution_a_items=`echo ${solution_a_items} | sed -r 's/<item>//g' | sed -r 's/<\/item>/, /g' | sed -r 's/(.*), $/\1/g'`
solution_b_items=`echo ${solution_b_items} | sed -r 's/<item>//g' | sed -r 's/<\/item>/, /g' | sed -r 's/(.*), $/\1/g'`

echo ${solution_a_items}
echo ${solution_b_items}