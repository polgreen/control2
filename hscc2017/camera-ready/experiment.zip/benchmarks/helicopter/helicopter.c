#include <dsverifier.h>

digital_system controller = {
        .b = { 0.005859375f },
        .b_uncertainty = { 0.0 },
        .b_size = 1,
        .a = { 0.25f, 0.125f },
        .a_uncertainty = { 0.0, 0.0 },
        .a_size = 2,
        .sample_time = 2,
};

implementation impl = {
        .int_bits = 3,
        .frac_bits = 7,
        .max = 1.0,
        .min = -1.0,
        .scale = 1,
};

digital_system plant = {
        .b = { 15.1315f, 17.8600f, 17.4549f },
        .b_uncertainty = { 0.0, 0.0, 0.0 },
        .b_size = 3,
        .a = { 1.0f, -2.6207f, 2.3586f, -0.6570f },
        .a_uncertainty = { 0.0, 0.0, 0.0, 0.0 },
        .a_size = 4,
};

