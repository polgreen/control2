int nondet_int();

int main() {
  nondet_int();
}
