int main()
{
  const void *p;
  int *q;
  int c;

  p=(c?p:0);

  p=(int * const)0;
}
