int func(int);

int main()
{
  int x;
  assert(func(x));
  return 0;
}
