int func(int x)
{
  return 1;
}
