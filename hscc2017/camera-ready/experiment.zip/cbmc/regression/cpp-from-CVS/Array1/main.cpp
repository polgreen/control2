int y[5][4][3][2];

int main()
{
  for(int i=0; i<5; i++)
    for(int j=0; j<4; j++)
      for(int k=0; k<3; k++)
        for(int l=0; l<2; l++)
          y[i][j][k][l]=2;
}
