char my_string[]="abc";

void elsewhere();

int main()
{
  elsewhere();
}
