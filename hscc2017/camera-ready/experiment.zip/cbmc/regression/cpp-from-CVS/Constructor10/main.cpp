class A
{
	public:
	int a;
	A(int a):a(a){}
};


A f()
{
	return A(0);
}

int main(){}
