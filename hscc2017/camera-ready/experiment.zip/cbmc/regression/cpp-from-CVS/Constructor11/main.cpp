struct A
{
	A(){};
};

int main()
{
	A a;
	a.A();
}
