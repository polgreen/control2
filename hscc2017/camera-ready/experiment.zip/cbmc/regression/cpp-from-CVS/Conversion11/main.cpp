char* func(){return (void*)0; }
