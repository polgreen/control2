int main()
{
	unsigned i = 1;
	unsigned j;
	j = i + 1;
	assert(j==2);
}
