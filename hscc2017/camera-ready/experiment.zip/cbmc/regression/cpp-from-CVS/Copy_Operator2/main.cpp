class A
{
	const int a;
	A():a(0){};
};

int main()
{
	A a,b;
	a=b;
}
