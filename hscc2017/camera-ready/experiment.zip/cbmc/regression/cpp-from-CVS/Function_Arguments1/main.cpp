inline void *memchr(void* __p, int __c, int __n)
{
  __p++;
}

int main()
{
}
