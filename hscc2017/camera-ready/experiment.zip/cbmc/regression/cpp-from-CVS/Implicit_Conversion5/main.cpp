void f(int);

int main()
{
	char* pc;
	f(pc); // invalid conversion
}
