int main()
{
	int a;
	assert(&a);
}
