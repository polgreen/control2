int main()
{
dummy_label:
	int i = 0;

	assert(i==0);
}
