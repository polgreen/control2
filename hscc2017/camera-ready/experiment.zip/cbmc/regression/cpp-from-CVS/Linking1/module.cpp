#include "module.h"

int i=1;

void T::f()
{
  i=2;
}
