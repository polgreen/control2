class T
{
public:
  void f();
};
