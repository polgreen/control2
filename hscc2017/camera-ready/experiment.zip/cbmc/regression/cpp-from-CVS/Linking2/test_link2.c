int x;

int f(void)
{
  return x;
}
