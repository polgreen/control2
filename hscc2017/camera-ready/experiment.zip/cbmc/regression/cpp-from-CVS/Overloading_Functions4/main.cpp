double pow(double _X, double _Y);
double pow(double _X, int _Y);
float pow(float _X, float _Y);
float pow(float _X, int _Y);
long double pow(long double _X, long double _Y);
long double pow(long double _X, int _Y);

int main()
{
  double x;
  // the literal types select the function
  x=pow(2.0f, 3);
}
