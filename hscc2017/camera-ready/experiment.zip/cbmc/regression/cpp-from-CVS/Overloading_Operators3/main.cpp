// this is *not* allowed
int operator[](int *p, int i);

int main()
{
}
