class A {
	static void func(){}
};

int main()
{
	A::func();
}
