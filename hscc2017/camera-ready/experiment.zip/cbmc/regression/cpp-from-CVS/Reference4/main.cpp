class A{
  int& a;
};
