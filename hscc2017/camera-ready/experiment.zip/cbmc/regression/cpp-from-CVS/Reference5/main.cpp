class A
{
    int & a;
    A():a(){}
};
