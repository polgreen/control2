int main()
{
  int *&* p; // parsing error
}
