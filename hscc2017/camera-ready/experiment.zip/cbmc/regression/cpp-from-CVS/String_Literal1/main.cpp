int main()
{
  const char *p="asd" "1";
  assert(p[3]=='1');
}
