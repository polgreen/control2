template <class T>
struct A {
  int a;
};

template <class T, class C>
struct A;
