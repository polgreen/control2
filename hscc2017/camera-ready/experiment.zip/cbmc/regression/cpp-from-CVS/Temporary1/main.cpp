int f(const int &i)
{
  assert(i==1);
}

int main()
{
  f(1);
}
