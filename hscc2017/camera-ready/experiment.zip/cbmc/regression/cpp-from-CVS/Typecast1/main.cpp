int main()
{
  const int *p;

  p=(int *)0;
}
