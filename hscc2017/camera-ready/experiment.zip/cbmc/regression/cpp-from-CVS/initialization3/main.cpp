class A
{
	public:
	int i;
	A(){}
};

int main()
{
	A a;
	assert(a.i==0);
}
