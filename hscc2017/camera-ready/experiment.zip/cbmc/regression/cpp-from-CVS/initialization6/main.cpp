extern "C" int g;

int main()
{
	assert(g==0);
}
