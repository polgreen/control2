union {
	int a;
	char b;
};

int main()
{
	assert(a == 0);
	assert(b == 0);
}
