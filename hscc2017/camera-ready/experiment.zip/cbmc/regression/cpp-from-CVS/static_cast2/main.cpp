int main()
{
	int x;
	static_cast<int>(x)++; // not ok
}
