#ifdef __APPLE__
void * _Nullable p1;
void * _Nonnull p2;

// block pointer
void (^p3)(void);
#endif
