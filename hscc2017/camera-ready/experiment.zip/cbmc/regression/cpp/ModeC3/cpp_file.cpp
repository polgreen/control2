extern "C" int some_function(int param)
{
  return param+1;
}
