struct A{};
int x;
int main()
{
	A a;
	a.x; // bad
}
