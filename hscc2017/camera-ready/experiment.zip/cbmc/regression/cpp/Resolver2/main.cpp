class A
{
	void f(int i){}
	void f(){f(0);}
};

int main(){}
