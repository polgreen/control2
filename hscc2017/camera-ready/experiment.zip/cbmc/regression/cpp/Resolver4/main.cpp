class A{
 public:
 void f(int i){};
};

int main()
{
	A::f(0);
}
