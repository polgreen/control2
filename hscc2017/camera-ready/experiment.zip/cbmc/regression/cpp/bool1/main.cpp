// _Bool is not a C++ keyword

typedef bool _Bool;

_Bool some_bool;
bool some_other_bool;

int main()
{
}
