int main()
{
  // 'a' is a duplicate
  int a;
  union {int  a;};
}
