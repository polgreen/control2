#!/bin/bash
export PATH=${PATH//jdk1.7.0_75/jdk1.8.0_20}
export PATH=${PATH//cbmc-5190/cbmc-trunk-diffblue-control-synthesis}
export PATH=${PATH}:/users/pkesseli/software/cpp/cbmc/cbmc-trunk-diffblue-control-synthesis/src/cegis:/users/pkesseli/software/cpp/cbmc/cbmc-trunk-diffblue-control-synthesis-analyzer/src/goto-analyzer:/users/pkesseli/software/cpp/z3/trunk/target/i686-linux/bin

function extract_variable {
 echo $1 | sed "s/.*$2 *= *\([^,]*\),.*/\1/"
}

function extract_array {
 pattern=".$2 *= *{ *\("
 i=0
 while [ ${i} -lt $3 ]; do
  pattern="${pattern} *[^, ]* *,"
  i=$((i+1))
 done
 pattern="${pattern%?}\)"
 echo $1 | sed "s/.*${pattern}.*/\1/"
}

function extend_array {
 missing_elements=`grep -o ',' <<< "$1" | grep -c .`
 missing_elements=$((missing_elements + 1))
 missing_elements=$(($2 - missing_elements))
 result="$1"
 i=0
 while [ ${i} -lt ${missing_elements} ]; do
  result="${result}, 0.000000"
  i=$((i+1))
 done
 echo ${result}
}

sizes_header_file='sizes.h'
plant_header_file='plant.h'
controller_header_file='controller.h'

benchmark_dir='/users/pkesseli/documents/control-synthesis/benchmarks/SpringMassDamper/'
#for benchmark_dir in /users/pkesseli/documents/control-synthesis/benchmarks/*/; do
 for benchmark in ${benchmark_dir}*.c; do
  impl_decl=`grep -Pzo '.*impl *=.*(\n.*?)*?;' ${benchmark}`
  impl_int_bits=$(extract_variable "${impl_decl}" 'int_bits')
  impl_frac_bits=$(extract_variable "${impl_decl}" 'frac_bits')

  controller_decl=`grep -Pzo '.*controller *=.*(\n.*?)*?;' ${benchmark}`
  controller_a_size=$(extract_variable "${controller_decl}" 'a_size')
  controller_b_size=$(extract_variable "${controller_decl}" 'b_size')
  controller_a=$(extract_array "${controller_decl}" 'a' "${controller_a_size}")
  controller_b=$(extract_array "${controller_decl}" 'b' "${controller_b_size}") 
  controller_a_uncertainty=$(extract_array "${controller_decl}" 'a_uncertainty' "${controller_a_size}")
  controller_b_uncertainty=$(extract_array "${controller_decl}" 'b_uncertainty' "${controller_b_size}")
  controller_sample_time=$(extract_variable "${controller_decl}" 'sample_time')

  plant_decl=`grep -Pzo '.*plant *=.*(\n.*?)*?;' ${benchmark}`
  plant_a_size=$(extract_variable "${plant_decl}" 'a_size')
  plant_b_size=$(extract_variable "${plant_decl}" 'b_size')
  plant_a=$(extract_array "${plant_decl}" 'a' "${plant_a_size}")
  plant_b=$(extract_array "${plant_decl}" 'b' "${plant_b_size}") 
  plant_a_uncertainty=$(extract_array "${plant_decl}" 'a_uncertainty' "${plant_a_size}")
  plant_b_uncertainty=$(extract_array "${plant_decl}" 'b_uncertainty' "${plant_b_size}")
  plant_sample_time=$(extract_variable "${plant_decl}" 'sample_time')

  struct_a_size=$(( a_size >= controller_a_size ? a_size : controller_a_size ))
  struct_b_size=$(( b_size >= controller_b_size ? b_size : controller_b_size ))
  plant_a=$(extend_array "${plant_a}" "${struct_a_size}")
  plant_a_uncertainty=$(extend_array "${plant_a_uncertainty}" "${struct_a_size}")
  plant_b=$(extend_array "${plant_b}" "${struct_b_size}")
  plant_b_uncertainty=$(extend_array "${plant_b_uncertainty}" "${struct_b_size}")
  controller_a=$(extend_array "${controller_a}" "${struct_a_size}")
  controller_a_uncertainty=$(extend_array "${controller_a_uncertainty}" "${struct_a_size}")
  controller_b=$(extend_array "${controller_b}" "${struct_b_size}")
  controller_b_uncertainty=$(extend_array "${controller_b_uncertainty}" "${struct_b_size}")

  echo "#define __PLANT_DEN_SIZE ${plant_a_size}" >${sizes_header_file}
  echo "#define __PLANT_NUM_SIZE ${plant_b_size}" >>${sizes_header_file}
  echo "#define __CONTROLLER_DEN_SIZE ${controller_a_size}" >>${sizes_header_file}
  echo "#define __CONTROLLER_NUM_SIZE ${controller_b_size}" >>${sizes_header_file}
  echo "#define SOLUTION_DEN_SIZE ${struct_a_size}" >>${sizes_header_file}
  echo "#define SOLUTION_NUM_SIZE ${struct_b_size}" >>${sizes_header_file}

  echo "struct anonymous3 plant={ .den={ ${plant_a} }, .den_uncertainty={ ${plant_a_uncertainty} }, .den_size=${plant_a_size}, .num={ ${plant_b} }, .num_uncertainty={ ${plant_b_uncertainty} }, .num_size=${plant_b_size} };" >${plant_header_file}
  echo "struct anonymous3 controller={ .den={ ${controller_a} }, .den_uncertainty={ ${controller_a_uncertainty} }, .den_size=${controller_a_size}, .num={ ${controller_b} }, .num_uncertainty={ ${controller_b_uncertainty} }, .num_size=${controller_b_size} };" >${controller_header_file}

 log_file="${benchmark%.c}.log"
 truncate -s 0 ${log_file}
 for word_width in {20..64..2}; do
  cegis -D __CPROVER -D _FIXEDBV -D _CONTROL_FLOAT_WIDTH=${word_width} -D _CONTROLER_INT_BITS=${impl_int_bits} -D _CONTROLER_FRAC_BITS=${impl_frac_bits} --fixedbv --round-to-minus-inf --cegis-control --cegis-statistics --cegis-genetic --cegis-max-size 1 simplified_noise.c >>${log_file} 2>&1
  if [ $? -eq 0 ]; then break; fi
 done

 q_log_file="${benchmark%.c}_q.log"
 truncate -s 0 ${q_log_file}
 for word_width in {20..64..2}; do
  cbmc -D __CPROVER -D _FIXEDBV -D _CONTROL_FLOAT_WIDTH=${word_width} -D _CONTROLER_INT_BITS=${impl_int_bits} -D _CONTROLER_FRAC_BITS=${impl_frac_bits} --fixedbv --stop-on-fail --round-to-minus-inf simplified_noiseQ.c >>${q_log_file} 2>&1
  if [ $? -eq 10 ]; then break; fi
 done

 done
#done
